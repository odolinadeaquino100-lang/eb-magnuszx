require("dotenv").config();
const express = require("express");
const fs = require("fs");
const path = require("path");

const app = express();
app.use(express.json({ limit: "20kb" }));
app.use(express.static(path.join(__dirname, "public")));

const DATA_FILE = path.join(__dirname, "cdp-data.json");
function loadData() {
  try { return JSON.parse(fs.readFileSync(DATA_FILE, "utf8")); }
  catch { return { members: {} }; }
}
function saveData(data) {
  fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2), { mode: 0o600 });
}
function cleanUsername(value) {
  return typeof value === "string" ? value.trim().replace(/^@/, "").slice(0, 20) : "";
}
const rankHours = [
  ["Recruta",3],["Soldado",6],["Cabo",12],["3º Sargento",15],["2º Sargento",20],
  ["1º Sargento",25],["Subtenente",30],["Cadete",35],["Aspirante a Oficial",40],
  ["3º Tenente",45],["2º Tenente",50],["1º Tenente",55],["Capitão",60],["Major",65],
  ["Tenente-Coronel",70],["Coronel",75],["General de Brigada",80],
  ["General de Divisão",85],["General de Exército",90],
  ["Elite Militar",250],["Elite Secreta",350],["Elite Real",500]
];
app.get("/api/health", (_req,res) => res.json({ ok:true, service:"EB Magnuszx CDP" }));

app.post("/api/roblox/lookup", async (req,res) => {
  const username = cleanUsername(req.body?.username);
  if (!username || username.length < 3) return res.status(400).json({ error:"Digite um nome de usuário Roblox válido." });
  try {
    const response = await fetch("https://users.roblox.com/v1/usernames/users", {
      method:"POST", headers:{"Content-Type":"application/json"},
      body:JSON.stringify({ usernames:[username], excludeBannedUsers:false })
    });
    if (!response.ok) return res.status(502).json({ error:"O Roblox não respondeu à consulta. Tente novamente." });
    const body = await response.json();
    const user = body.data?.[0];
    if (!user) return res.status(404).json({ error:"Usuário não encontrado. Confira a escrita do nome." });
    const member = loadData().members[String(user.id)] || null;
    let cdp = null;
    if (member) {
      const rankSince = member.rankSince || null;
      const elapsedHours = rankSince ? Math.max(0, Math.floor((Date.now() - new Date(rankSince).getTime()) / 3600000)) : 0;
      cdp = {
        rank: member.rank,
        rankSince,
        elapsedHours,
        hoursRecorded: member.hoursRecorded || 0,
        nextRank: nextRank(member.rank),
        requiredHours: requiredForNext(member.rank),
        historyCount: Array.isArray(member.history) ? member.history.length : 0
      };
    }
    res.json({
      user:{ id:user.id, username:user.name, displayName:user.displayName,
        profileUrl:`https://www.roblox.com/users/${user.id}/profile` },
      cdp,
      message: cdp ? "Conta encontrada e registro CDP localizado." : "Conta encontrada, mas ainda não existe registro interno de tempo de patente na CDP."
    });
  } catch (e) {
    console.error("lookup error", e.message);
    res.status(502).json({ error:"Não foi possível consultar o Roblox agora." });
  }
});
function rankIndex(rank) { return rankHours.findIndex(r => r[0] === rank); }
function nextRank(rank) { const i=rankIndex(rank); return i>=0 && i<rankHours.length-1 ? rankHours[i+1][0] : null; }
function requiredForNext(rank) { const i=rankIndex(rank); return i>=0 && i<rankHours.length-1 ? rankHours[i+1][1] : null; }

app.get("/api/cdp/ranks", (_req,res) => res.json({ ranks:rankHours.map(([rank,requiredHours])=>({rank,requiredHours})) }));

// Estrutura preparada para ciclos de CDP:
// ao registrar uma promoção, arquive a patente anterior e comece a nova com rankSince = agora.
// Não há endpoint público de promoção neste pacote, pois ele exige OAuth, sessão e autorização de oficial.
function archiveAndStartNewCdpCycle(member, newRank, officerId, timestamp = new Date().toISOString()) {
  const history = Array.isArray(member.history) ? member.history : [];
  if (member.rank) {
    const started = member.rankSince ? new Date(member.rankSince).getTime() : NaN;
    const ended = new Date(timestamp).getTime();
    history.push({
      rank: member.rank,
      rankSince: member.rankSince || null,
      rankEndedAt: timestamp,
      hoursInRank: Number.isFinite(started) ? Math.max(0, Math.floor((ended - started) / 3600000)) : 0,
      promotedBy: officerId || null
    });
  }
  return { ...member, rank: newRank, rankSince: timestamp, hoursRecorded: 0, history };
}
// Mantém a função disponível para futura integração segura sem expor escrita HTTP não autenticada.
void archiveAndStartNewCdpCycle;
void saveData;

app.get("/auth/roblox/start", (_req,res) => {
  res.status(503).send("O botão mantém a interface, mas o login oficial Roblox ainda não está conectado. Configure o OAuth oficial antes de publicar.");
});

const port = Number(process.env.PORT || 3000);
app.listen(port, () => console.log(`EB Magnuszx CDP disponível em http://localhost:${port}`));
